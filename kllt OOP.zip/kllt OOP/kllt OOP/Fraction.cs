﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kllt_OOP
{
    class Fraction
    {
        private int numerator;
        private int denominator;

        public int Numerator
        {
            get { return numerator; }
            set { numerator = value; }
        }

        public int Denominator
        {
            get { return denominator; }
            set
            {
                if (value == 0)
                {
                    Console.WriteLine("Invalid denominator. Set default to 1.");
                    denominator = 1;
                }
                else
                {
                    denominator = value;
                }
            }
        }

        public Fraction()
        {
            Numerator = 0;
            Denominator = 1;
        }

        public Fraction(int numerator, int denominator)
        {
            Numerator = numerator;
            Denominator = denominator;
            Simplify();
        }

        public Fraction(int numerator)
        {
            Numerator = numerator;
            Denominator = 1;
            Simplify();
        }

        private int GCD(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (a != 0 && b != 0)
            {
                if (a > b) a %= b;
                else b %= a;
            }
            return a | b;
        }

        public void Simplify()
        {
            int gcd = GCD(Numerator, Denominator);
            if (gcd > 0)
            {
                Numerator /= gcd;
                Denominator /= gcd;
            }
            if (Denominator < 0)
            {
                Numerator = -Numerator;
                Denominator = -Denominator;
            }
        }

        public void Input()
        {
            Console.Write("Enter numerator: ");
            Numerator = int.Parse(Console.ReadLine()!);

            int d;
            do
            {
                Console.Write("Enter denominator (cannot be 0): ");
                d = int.Parse(Console.ReadLine()!);
            } while (d == 0);

            Denominator = d;
            Simplify();
        }

        public double Decimal()
        {
            return (double)Numerator / Denominator;
        }

        public Fraction Add(Fraction p)
        {
            Fraction res = new Fraction(
                this.Numerator * p.Denominator + p.Numerator * this.Denominator,
                this.Denominator * p.Denominator);
            res.Simplify();
            return res;
        }

        public Fraction Subtract(Fraction p)
        {
            Fraction res = new Fraction(
                this.Numerator * p.Denominator - p.Numerator * this.Denominator,
                this.Denominator * p.Denominator);
            res.Simplify();
            return res;
        }

        public Fraction Multiply(Fraction p)
        {
            Fraction res = new Fraction(
                this.Numerator * p.Numerator,
                this.Denominator * p.Denominator);
            res.Simplify();
            return res;
        }

        public Fraction Divide(Fraction p)
        {
            Fraction res = new Fraction(
                this.Numerator * p.Denominator,
                this.Denominator * p.Numerator);
            res.Simplify();
            return res;
        }

        public override string ToString()
        {
            return $"{Numerator}/{Denominator}";
        }
    }
}
