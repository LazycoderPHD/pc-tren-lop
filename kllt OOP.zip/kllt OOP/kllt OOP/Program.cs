﻿using kllt_OOP;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;
/* cách 1: default constructor + Input()
 * Student svA = new Student();
 * svA.Input();
 * svA.PrintInfo();
 * 
 * Cách 2: default constructor + property
 * Student svB = new Student();
*/

Console.WriteLine("--- BÀI TẬP 1: CLASS STUDENT ---");
Student sv = new Student();
sv.Input();
Console.WriteLine("\nThông tin sinh viên:");

sv.PrintInfo();
Console.WriteLine($"Tuổi: {sv.GetAge()}");

Console.WriteLine("\n--- BÀI TẬP 2: CLASS FRACTION ---");
Fraction f1 = new Fraction();
Console.WriteLine("Nhập phân số 1:");
f1.Input();

Fraction f2 = new Fraction();
Console.WriteLine("Nhập phân số 2:");
f2.Input();

Console.WriteLine($"\nPhân số 1: {f1.ToString()} (Thập phân: {f1.Decimal()})");
Console.WriteLine($"Phân số 2: {f2.ToString()} (Thập phân: {f2.Decimal()})");

Console.WriteLine($"Cộng: {f1.Add(f2).ToString()}");
Console.WriteLine($"Trừ: {f1.Subtract(f2).ToString()}");
Console.WriteLine($"Nhân: {f1.Multiply(f2).ToString()}");
Console.WriteLine($"Chia: {f1.Divide(f2).ToString()}");
