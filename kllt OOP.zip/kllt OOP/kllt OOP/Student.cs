﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kllt_OOP
{
    internal class Student
    {
        //Attribute/Field
        private string studentId;
        private string name;
        private int birthYear;
        private bool gender;
        private string stdClass;

        //Constructor
        public Student()
        {



        }

        public Student(string studentId, string name, int birthYear, bool gender, string stdClass)
        {
            //xét điều kiện cho tham số đầu vào
            this.studentId = studentId;
            this.name = name;
            //this.birthYear = birthYear;
            if(birthYear >= 1900 && birthYear <= DateTime.Now.Year)
            {
                this.birthYear = birthYear;
            }
            else
            {
                Console.WriteLine("Nhap nam sinh sai!");
                this.birthYear = 1900;
            }
            this.gender = gender;
            this.stdClass = stdClass;
        }

        public string Name
        {
            //get: lấy giá trị thuộc tính ra
            get { return this.name; }
            //set: nhập giá trị mới
            set
            {
                this.name = value;
            }
        }

        public int BirthYear
        {
            get {return birthYear;}
            set
            {
                if(value >= 1900 && value <= DateTime.Now.Year)
                {
                    this.birthYear = value; //2007
                }
                else
                {
                    Console.WriteLine("Nhap nam sinh sai!");
                    this.BirthYear = 1900; //set deyfault to 1900

                }
            }
        }

        // 3 property cho 3 thuoc tinh con lai

        //method
        public void Input()
        {
            Console.Write("Enter StudentID: ");
            this.studentId = Console.ReadLine()!;
            Console.Write("Enter your name: ");
            this.name = Console.ReadLine()!;
            Console.Write("Enter BirthYear: ");
            this.BirthYear = Convert.ToInt32(Console.ReadLine()!); //int namsinh
            Console.Write("Enter gender: True = Male, False = Female: ");
            this.gender = bool.Parse(Console.ReadLine()!);
            Console.Write("Enter StudentClass: ");
            this.stdClass = Console.ReadLine()!;
        }

        public int GetAge()
        {
            return DateTime.Now.Year - this.birthYear;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"StudentID: {this.studentId}");
            Console.WriteLine($"Name: {this.name}");
            Console.WriteLine($"Birth Year: {birthYear}");
            Console.WriteLine($"Gender: {(gender ? "Male" : "Female")}");
            Console.WriteLine($"Class: {stdClass}");
        }

        

    }
}
